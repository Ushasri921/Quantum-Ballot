import Database from 'better-sqlite3';
import path from 'path';
import bcrypt from 'bcryptjs';

const db = new Database('voting.db');

// Initialize tables - This section defines the core schema for our voting system.
// We use users for authentication, candidates for election roles, 
// votes for storing the cast ballots, and audit_logs for security tracking.
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    roll_number TEXT UNIQUE NOT NULL,
    phone TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    has_voted BOOLEAN DEFAULT 0,
    failed_attempts INTEGER DEFAULT 0,
    locked_until DATETIME
  );

  CREATE TABLE IF NOT EXISTS candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    department TEXT NOT NULL,
    role TEXT NOT NULL,
    photo_url TEXT
  );

  CREATE TABLE IF NOT EXISTS votes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    candidate_id INTEGER NOT NULL,
    role TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id)
  );

  CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    action TEXT NOT NULL,
    user_id INTEGER,
    details TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );
`);

// Seed initial data if empty
const candidateCount = db.prepare('SELECT COUNT(*) as count FROM candidates').get() as { count: number };
if (candidateCount.count === 0) {
  const insertCandidate = db.prepare('INSERT INTO candidates (name, department, role) VALUES (?, ?, ?)');
  
  const initialCandidates = [
    // President
    ['A. Rahul Reddy', 'CSE (Cyber Security)', 'President'],
    ['B. Keerthana Rao', 'ECE', 'President'],
    ['C. Sai Kiran', 'Mechanical', 'President'],
    ['D. Meghana Sharma', 'IT', 'President'],
    // Vice President
    ['E. Harsha Vardhan', 'CSE', 'Vice President'],
    ['F. Sneha Patel', 'Civil', 'Vice President'],
    ['G. Rohit Kumar', 'EEE', 'Vice President'],
    ['H. Divya Sri', 'AI & ML', 'Vice President'],
    // Treasurer
    ['I. Ajay Kumar', 'MBA', 'Treasurer'],
    ['J. Bhavana Reddy', 'CSE', 'Treasurer'],
    ['K. Nithin Reddy', 'ECE', 'Treasurer'],
    ['L. Pooja Singh', 'IT', 'Treasurer'],
    // Sports Captain
    ['M. Arjun Naik', 'Mechanical', 'Sports Captain'],
    ['N. Tejaswini', 'CSE', 'Sports Captain'],
    ['O. Varun Raj', 'EEE', 'Sports Captain'],
    ['P. Kavya', 'Civil', 'Sports Captain'],
    // Cultural Captain
    ['Q. Sandeep', 'IT', 'Cultural Captain'],
    ['R. Lavanya', 'CSE', 'Cultural Captain'],
    ['S. Pranav', 'ECE', 'Cultural Captain'],
    ['T. Harini', 'MBA', 'Cultural Captain'],
  ];

  for (const [name, dept, role] of initialCandidates) {
    insertCandidate.run(name, dept, role);
  }

  // Seed Admin
  const adminPassword = bcrypt.hashSync('admin123', 10);
  db.prepare('INSERT OR IGNORE INTO users (name, roll_number, phone, email, password, role) VALUES (?, ?, ?, ?, ?, ?)')
    .run('Admin', 'ADMIN001', '0000000000', 'admin@nrcer.ac.in', adminPassword, 'admin');

  // Initial settings
  db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)').run('voting_enabled', 'true');
}

export default db;
