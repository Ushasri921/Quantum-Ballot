export interface User {
  id: number;
  name: string;
  role: 'user' | 'admin';
  hasVoted: boolean;
}

export interface Candidate {
  id: number;
  name: string;
  department: string;
  role: string;
  photo_url?: string;
}

export interface VoteSelections {
  [role: string]: number;
}

export const ROLES = [
  { name: 'President', icon: '🏛' },
  { name: 'Vice President', icon: '🤝' },
  { name: 'Treasurer', icon: '💰' },
  { name: 'Sports Captain', icon: '🏆' },
  { name: 'Cultural Captain', icon: '🎭' },
];

export const COLORS = {
  lavender: '#E6E6FA',
  mint: '#F5FFFA',
  blue: '#F0F8FF',
  peach: '#FFDAB9',
};
