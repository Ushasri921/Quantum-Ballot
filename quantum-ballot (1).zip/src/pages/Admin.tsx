import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend 
} from 'recharts';
import { 
  Users, Vote, Clock, Percent, LogOut, RefreshCw, Shield, 
  Download, Trash2, Power
} from 'lucide-react';
import { motion } from 'motion/react';
import { ROLES } from '../types';

export default function Admin() {
  const [stats, setStats] = useState<any>(null);
  const [results, setResults] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [votingEnabled, setVotingEnabled] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    if (!localStorage.getItem('token') || user.role !== 'admin') {
      navigate('/login');
      return;
    }
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const config = { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } };
      const [statsRes, resultsRes] = await Promise.all([
        axios.get('/api/admin/stats', config),
        axios.get('/api/admin/results', config)
      ]);
      setStats(statsRes.data);
      setResults(resultsRes.data);
    } catch (err) {
      console.error('Failed to fetch admin data');
    } finally {
      setLoading(false);
    }
  };

  const toggleVoting = async () => {
    try {
      await axios.post('/api/admin/toggle-voting', { enabled: !votingEnabled }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setVotingEnabled(!votingEnabled);
      alert(`Voting ${!votingEnabled ? 'enabled' : 'disabled'}`);
    } catch (err) {
      alert('Failed to toggle voting');
    }
  };

  const resetElection = async () => {
    if (!window.confirm('WARNING: This will delete ALL cast votes and reset the election. Are you sure?')) return;
    try {
      await axios.post('/api/admin/reset-election', {}, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      alert('Election reset successfully');
      fetchData();
    } catch (err) {
      alert('Failed to reset election');
    }
  };

  const exportCSV = () => {
    if (!results) return;
    let csv = 'Role,Candidate,Department,Votes\n';
    Object.entries(results).forEach(([role, candidates]: any) => {
      candidates.forEach((c: any) => {
        csv += `${role},${c.name},${c.department},${c.vote_count}\n`;
      });
    });
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('hidden', '');
    a.setAttribute('href', url);
    a.setAttribute('download', 'election_results.csv');
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  if (loading) return <div className="flex items-center justify-center min-h-screen">Loading Admin Dashboard...</div>;

  const PIE_COLORS = ['#818CF8', '#34D399', '#FBBF24', '#F87171', '#A78BFA'];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Sidebar/Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-indigo-600" />
            <h1 className="text-xl font-bold text-slate-800">Quantum Ballot Admin</h1>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={fetchData} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
              <RefreshCw className="w-5 h-5 text-slate-600" />
            </button>
            <button onClick={handleLogout} className="flex items-center gap-2 text-red-500 font-semibold hover:bg-red-50 px-4 py-2 rounded-lg transition-colors">
              <LogOut className="w-5 h-5" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            { label: 'Registered Students', value: stats?.totalRegistered, icon: Users, color: 'bg-blue-500' },
            { label: 'Total Votes Cast', value: stats?.totalVotes, icon: Vote, color: 'bg-emerald-500' },
            { label: 'Pending Voters', value: stats?.pendingVoters, icon: Clock, color: 'bg-amber-500' },
            { label: 'Voting Percentage', value: `${stats?.votingPercentage}%`, icon: Percent, color: 'bg-indigo-500' },
          ].map((item, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-xl ${item.color} text-white`}>
                  <item.icon className="w-6 h-6" />
                </div>
              </div>
              <h3 className="text-slate-500 text-sm font-medium">{item.label}</h3>
              <p className="text-2xl font-bold text-slate-800 mt-1">{item.value}</p>
            </motion.div>
          ))}
        </div>

        {/* Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2 bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-bold text-slate-800">Live Election Results</h2>
              <button onClick={exportCSV} className="flex items-center gap-2 text-sm font-semibold text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-lg transition-colors">
                <Download className="w-4 h-4" />
                Export CSV
              </button>
            </div>

            <div className="space-y-12">
              {ROLES.map(role => (
                <div key={role.name}>
                  <h3 className="text-lg font-bold text-slate-700 mb-4 flex items-center gap-2">
                    <span>{role.icon}</span> {role.name}
                  </h3>
                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={results?.[role.name] || []} layout="vertical" margin={{ left: 40, right: 40 }}>
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                        <XAxis type="number" hide />
                        <YAxis dataKey="name" type="category" width={120} tick={{ fontSize: 12 }} />
                        <Tooltip />
                        <Bar dataKey="vote_count" fill="#818CF8" radius={[0, 4, 4, 0]} barSize={20} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
              <h2 className="text-xl font-bold text-slate-800 mb-6">System Controls</h2>
              <div className="space-y-4">
                <button 
                  onClick={toggleVoting}
                  className={`w-full flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${
                    votingEnabled 
                    ? 'border-emerald-100 bg-emerald-50 text-emerald-700' 
                    : 'border-red-100 bg-red-50 text-red-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Power className="w-5 h-5" />
                    <span className="font-bold">{votingEnabled ? 'Voting Active' : 'Voting Paused'}</span>
                  </div>
                  <div className={`w-12 h-6 rounded-full relative transition-colors ${votingEnabled ? 'bg-emerald-500' : 'bg-red-500'}`}>
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${votingEnabled ? 'right-1' : 'left-1'}`} />
                  </div>
                </button>

                <button 
                  onClick={resetElection}
                  className="w-full flex items-center gap-3 p-4 rounded-2xl border-2 border-slate-100 hover:border-red-200 hover:bg-red-50 text-slate-600 hover:text-red-600 transition-all"
                >
                  <Trash2 className="w-5 h-5" />
                  <span className="font-bold">Reset Election Data</span>
                </button>
              </div>
            </div>

            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
              <h2 className="text-xl font-bold text-slate-800 mb-6">Participation Overview</h2>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Voted', value: stats?.totalVotes },
                        { name: 'Pending', value: stats?.pendingVoters }
                      ]}
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      <Cell fill="#34D399" />
                      <Cell fill="#F3F4F6" />
                    </Pie>
                    <Tooltip />
                    <Legend verticalAlign="bottom" height={36}/>
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
