import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { LogOut, CheckCircle, AlertCircle, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ROLES, Candidate, VoteSelections } from '../types';

export default function Dashboard() {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [selections, setSelections] = useState<VoteSelections>({});
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [voted, setVoted] = useState(false);
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    if (!localStorage.getItem('token')) {
      navigate('/login');
      return;
    }
    if (user.hasVoted) {
      setVoted(true);
      setLoading(false);
      return;
    }
    fetchCandidates();
  }, []);

  const fetchCandidates = async () => {
    try {
      const res = await axios.get('/api/candidates', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setCandidates(res.data);
    } catch (err) {
      console.error('Failed to fetch candidates');
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (role: string, candidateId: number) => {
    setSelections(prev => ({ ...prev, [role]: candidateId }));
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/login');
  };

  const submitVote = async () => {
    setSubmitting(true);
    try {
      await axios.post('/api/vote', { selections }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setVoted(true);
      setShowConfirm(false);
      // Update local user state
      const updatedUser = { ...user, hasVoted: true };
      localStorage.setItem('user', JSON.stringify(updatedUser));
    } catch (err: any) {
      alert(err.response?.data?.error || 'Failed to cast vote');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div className="flex items-center justify-center min-h-screen">Loading...</div>;

  if (voted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-mint">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="max-w-md w-full pastel-card p-12 text-center"
        >
          <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-12 h-12 text-emerald-500" />
          </div>
          <h1 className="text-3xl font-bold text-slate-800 mb-4">Vote Recorded!</h1>
          <p className="text-slate-600 mb-8">
            Your vote has been securely recorded in the Quantum Ballot system. Thank you for participating in the Narsimha Reddy Engineering College elections.
          </p>
          <button onClick={handleLogout} className="btn-primary w-full">
            Logout Securely
          </button>
        </motion.div>
      </div>
    );
  }

  const allRolesSelected = ROLES.every(role => selections[role.name]);

  return (
    <div className="min-h-screen bg-soft-blue pb-24">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md sticky top-0 z-10 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🗳️</span>
            <h1 className="text-xl font-bold text-slate-800">Quantum Ballot</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="hidden md:block text-sm text-slate-600">Welcome, <b>{user.name}</b></span>
            <button onClick={handleLogout} className="p-2 hover:bg-red-50 text-red-500 rounded-lg transition-colors">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8 p-4 bg-indigo-50 border border-indigo-100 rounded-2xl flex gap-3 items-start">
          <Info className="w-5 h-5 text-indigo-500 mt-0.5" />
          <p className="text-sm text-indigo-700">
            Please select one candidate for each role. You can only vote once. Your selections are final after confirmation.
          </p>
        </div>

        <div className="space-y-12">
          {ROLES.map((role, roleIdx) => (
            <section key={role.name}>
              <div className="flex items-center gap-3 mb-6">
                <span className="text-3xl">{role.icon}</span>
                <h2 className="text-2xl font-bold text-slate-800">{role.name}</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {candidates.filter(c => c.role === role.name).map((candidate) => (
                  <motion.div
                    key={candidate.id}
                    whileHover={{ y: -4 }}
                    className={`pastel-card p-6 cursor-pointer transition-all border-2 ${
                      selections[role.name] === candidate.id 
                      ? 'border-indigo-400 bg-indigo-50/50' 
                      : 'border-transparent hover:border-slate-200'
                    }`}
                    onClick={() => handleSelect(role.name, candidate.id)}
                  >
                    <div className="w-20 h-20 bg-slate-100 rounded-full mx-auto mb-4 flex items-center justify-center text-2xl text-slate-400">
                      👤
                    </div>
                    <div className="text-center">
                      <h3 className="font-bold text-slate-800">{candidate.name}</h3>
                      <p className="text-xs text-slate-500 mt-1 uppercase tracking-wider">{candidate.department}</p>
                    </div>
                    <div className="mt-4 flex justify-center">
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                        selections[role.name] === candidate.id 
                        ? 'border-indigo-500 bg-indigo-500' 
                        : 'border-slate-300'
                      }`}>
                        {selections[role.name] === candidate.id && <div className="w-2 h-2 bg-white rounded-full" />}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </section>
          ))}
        </div>
      </main>

      {/* Floating Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/80 backdrop-blur-lg border-t border-slate-200">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="text-sm text-slate-600">
            {Object.keys(selections).length} of {ROLES.length} roles selected
          </div>
          <button
            disabled={!allRolesSelected}
            onClick={() => setShowConfirm(true)}
            className="btn-primary disabled:opacity-50 disabled:grayscale"
          >
            Review & Cast Vote
          </button>
        </div>
      </div>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {showConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="max-w-lg w-full bg-white rounded-3xl p-8 shadow-2xl"
            >
              <h2 className="text-2xl font-bold text-slate-800 mb-6">Review Your Selection</h2>
              <div className="space-y-4 mb-8">
                {ROLES.map(role => {
                  const candidate = candidates.find(c => c.id === selections[role.name]);
                  return (
                    <div key={role.name} className="flex justify-between items-center p-3 bg-slate-50 rounded-xl">
                      <span className="text-sm font-medium text-slate-500">{role.name}</span>
                      <span className="font-bold text-slate-800">{candidate?.name}</span>
                    </div>
                  );
                })}
              </div>
              
              <div className="flex gap-4">
                <button 
                  onClick={() => setShowConfirm(false)}
                  className="flex-1 py-3 rounded-xl border border-slate-200 font-semibold hover:bg-slate-50"
                >
                  Edit Selection
                </button>
                <button 
                  onClick={submitVote}
                  disabled={submitting}
                  className="flex-1 btn-primary py-3 font-semibold flex items-center justify-center gap-2"
                >
                  {submitting ? 'Recording...' : 'Confirm Vote'}
                </button>
              </div>
              <p className="text-center text-xs text-slate-400 mt-4">
                By clicking confirm, your vote will be locked and cannot be changed.
              </p>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
