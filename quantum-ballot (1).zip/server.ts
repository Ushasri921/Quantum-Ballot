import express from 'express';
import { createServer as createViteServer } from 'vite';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import db from './src/db';
import dotenv from 'dotenv';

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || 'quantum-ballot-secret-2026';

async function startServer() {
  const app = express();
  app.use(express.json());

  // Auth Middleware
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.status(401).json({ error: 'Access denied' });

    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) return res.status(403).json({ error: 'Invalid token' });
      req.user = user;
      next();
    });
  };

  const isAdmin = (req: any, res: any, next: any) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required' });
    next();
  };

  // --- API Routes ---

  // Register
  app.post('/api/auth/register', async (req, res) => {
    const { name, rollNumber, phone, email, password } = req.body;

    // Validation
    if (!email.endsWith('@nrcer.ac.in')) {
      return res.status(400).json({ error: 'Only official college domain emails are allowed.' });
    }
    if (phone.length !== 10) {
      return res.status(400).json({ error: 'Phone number must be 10 digits.' });
    }

    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const stmt = db.prepare('INSERT INTO users (name, roll_number, phone, email, password) VALUES (?, ?, ?, ?, ?)');
      stmt.run(name, rollNumber, phone, email, hashedPassword);
      res.status(201).json({ message: 'Registration successful' });
    } catch (err: any) {
      if (err.message.includes('UNIQUE')) {
        return res.status(400).json({ error: 'Roll number or email already registered.' });
      }
      res.status(500).json({ error: 'Registration failed' });
    }
  });

  // Login
  app.post('/api/auth/login', async (req, res) => {
    const { identifier, password } = req.body; // identifier can be roll number or email

    const user = db.prepare('SELECT * FROM users WHERE roll_number = ? OR email = ?').get(identifier, identifier) as any;

    if (!user) return res.status(400).json({ error: 'User not found' });

    // Check if locked
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      return res.status(403).json({ error: 'Account locked. Try again later.' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      const attempts = user.failed_attempts + 1;
      if (attempts >= 5) {
        const lockTime = new Date(Date.now() + 15 * 60 * 1000); // 15 mins
        db.prepare('UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?').run(attempts, lockTime.toISOString(), user.id);
        return res.status(403).json({ error: 'Account locked due to multiple failed attempts.' });
      }
      db.prepare('UPDATE users SET failed_attempts = ? WHERE id = ?').run(attempts, user.id);
      return res.status(400).json({ error: 'Invalid password' });
    }

    // Reset attempts on success
    db.prepare('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?').run(user.id);

    const token = jwt.sign({ id: user.id, role: user.role, name: user.name, hasVoted: user.has_voted }, JWT_SECRET, { expiresIn: '1h' });
    res.json({ token, user: { id: user.id, name: user.name, role: user.role, hasVoted: user.has_voted } });
  });

  // Get Candidates
  app.get('/api/candidates', authenticateToken, (req, res) => {
    const candidates = db.prepare('SELECT * FROM candidates').all();
    res.json(candidates);
  });

  // Cast Vote - This is the most critical endpoint.
  // It uses a database transaction to ensure atomicity: either all votes are recorded 
  // and the user is marked as 'voted', or nothing happens. This prevents partial votes.
  app.post('/api/vote', authenticateToken, (req: any, res) => {
    const { selections } = req.body; // { role: candidateId }
    const userId = req.user.id;

    // Check if voting enabled
    const votingEnabled = db.prepare('SELECT value FROM settings WHERE key = ?').get('voting_enabled') as any;
    if (votingEnabled.value !== 'true') {
      return res.status(403).json({ error: 'Voting is currently disabled by admin.' });
    }

    // Check if already voted
    const user = db.prepare('SELECT has_voted FROM users WHERE id = ?').get(userId) as any;
    if (user.has_voted) {
      return res.status(403).json({ error: 'You have already cast your vote.' });
    }

    try {
      const insertVote = db.prepare('INSERT INTO votes (user_id, candidate_id, role) VALUES (?, ?, ?)');
      const updateUser = db.prepare('UPDATE users SET has_voted = 1 WHERE id = ?');

      const transaction = db.transaction(() => {
        for (const [role, candidateId] of Object.entries(selections)) {
          insertVote.run(userId, candidateId, role);
        }
        updateUser.run(userId);
        db.prepare('INSERT INTO audit_logs (action, user_id, details) VALUES (?, ?, ?)').run('VOTE_CAST', userId, JSON.stringify(selections));
      });

      transaction();
      res.json({ message: 'Vote securely recorded' });
    } catch (err) {
      res.status(500).json({ error: 'Failed to record vote' });
    }
  });

  // Admin Stats
  app.get('/api/admin/stats', authenticateToken, isAdmin, (req, res) => {
    const totalUsers = db.prepare('SELECT COUNT(*) as count FROM users WHERE role = "user"').get() as any;
    const totalVotes = db.prepare('SELECT COUNT(DISTINCT user_id) as count FROM votes').get() as any;
    const pendingVoters = totalUsers.count - totalVotes.count;
    const votingPercentage = totalUsers.count > 0 ? (totalVotes.count / totalUsers.count) * 100 : 0;

    res.json({
      totalRegistered: totalUsers.count,
      totalVotes: totalVotes.count,
      pendingVoters,
      votingPercentage: votingPercentage.toFixed(2)
    });
  });

  // Admin Results
  app.get('/api/admin/results', authenticateToken, isAdmin, (req, res) => {
    const roles = ['President', 'Vice President', 'Treasurer', 'Sports Captain', 'Cultural Captain'];
    const results: any = {};

    for (const role of roles) {
      results[role] = db.prepare(`
        SELECT c.name, c.department, COUNT(v.id) as vote_count
        FROM candidates c
        LEFT JOIN votes v ON c.id = v.candidate_id
        WHERE c.role = ?
        GROUP BY c.id
        ORDER BY vote_count DESC
      `).all(role);
    }

    res.json(results);
  });

  // Admin Controls
  app.post('/api/admin/toggle-voting', authenticateToken, isAdmin, (req, res) => {
    const { enabled } = req.body;
    db.prepare('UPDATE settings SET value = ? WHERE key = ?').run(enabled.toString(), 'voting_enabled');
    res.json({ message: `Voting ${enabled ? 'enabled' : 'disabled'}` });
  });

  app.post('/api/admin/reset-election', authenticateToken, isAdmin, (req, res) => {
    db.transaction(() => {
      db.prepare('DELETE FROM votes').run();
      db.prepare('UPDATE users SET has_voted = 0').run();
      db.prepare('INSERT INTO audit_logs (action, details) VALUES (?, ?)').run('ELECTION_RESET', 'All votes cleared');
    })();
    res.json({ message: 'Election reset successfully' });
  });

  // --- Vite Integration ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (req, res) => res.sendFile('dist/index.html', { root: '.' }));
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Quantum Ballot Server running at http://localhost:${PORT}`);
  });
}

startServer();
